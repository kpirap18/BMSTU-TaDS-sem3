#ifndef IO_H
#define IO_H

#include "defstrerr.h"

void print_hello();

void printf_input();

void clean_my();

func_var check_number(func_var *const number, const func_var l, const func_var r);

#endif // IO_H
