#ifndef TIME_H
#define TIME_H

#include "defstrerr.h"
#include "array.h"
#include "list.h"

void time_output(arrstack_r *arr, liststack_r *list, func_var max_);

#endif // TIME_H
