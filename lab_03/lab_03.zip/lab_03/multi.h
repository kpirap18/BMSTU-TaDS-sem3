#ifndef MULTI_H
#define MULTI_H

#include "defstrerr.h"

func_var multi_std(matrix_std_r *matrix, matrix_std_r *vector, matrix_std_r *res);

func_var multi_rr(matrix_r *matrix, matrix_r *vector, matrix_r *res);

#endif // MULTI_H
