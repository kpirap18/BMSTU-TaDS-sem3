#ifndef DO_H
#define DO_H

#include "defstrerr.h"
#include "io.h"

func_var do_action(func_var code_act);

#endif // DO_H
