#ifndef IO_H
#define IO_H

#include "app.h"

void print_hello();

void printf_input();

void clean_my();

int check_float(double *const number);

int check_number(int *const number, const int l, const int r);

void len_swow(queue_r *queue);

#endif // IO_H
